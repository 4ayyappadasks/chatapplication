import 'package:get/get.dart';

import '../../model/chatpage/chatpagemodel.dart';

class Chatcontroller extends GetxController {
  var List = <Messages>[].obs;
}
