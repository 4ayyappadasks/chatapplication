import 'package:flutter/material.dart';

class MessageCard extends StatelessWidget {
  const MessageCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }

  /// send message
  Widget _bluemessage() {
    return Container();
  }

  /// received message
  Widget _greeenmessage() {
    return Container();
  }
}
