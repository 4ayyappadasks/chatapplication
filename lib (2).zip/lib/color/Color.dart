import 'dart:ui';

const Color primaryColor = Color(0xFF0D0D58);

const Color secondaryColor = Color(0xFFE7CC4D);

const Color whiteColor = Color(0xFFFFFFFF);

const Color alertcolor = Color(0xFFFF0000);

const Color darkcolor = Color(0xFF000000);
