import 'package:chatapplication/commonwidgets/ChatCard/chatcardcontroller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class chatcard extends StatelessWidget {
  var username;

  var time;

  var description;

  chatcard({super.key, this.username, this.time, this.description});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(Chatcardcontroller());
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: InkWell(
        onTap: () {},
        child: ListTile(
          leading: CircleAvatar(
            child: Icon(Icons.person),
          ),
          trailing: Text(time ?? "12:00pm"),
          title: Text(
            username ?? "User name",
            style: TextStyle(color: Colors.black38),
          ),
          subtitle: Text(
            description ?? "last user message",
            maxLines: 1,
          ),
        ),
      ),
    );
  }
}
