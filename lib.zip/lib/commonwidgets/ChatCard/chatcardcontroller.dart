import 'package:get/get.dart';

class Chatcardcontroller extends GetxController{}