import 'dart:developer';
import 'dart:io';

import 'package:chatapplication/auth/apis.dart';
import 'package:chatapplication/commonwidgets/widgets.dart';
import 'package:chatapplication/view/homepage/ui/homepage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class Loginpagecontroll extends GetxController {
  Future<UserCredential?> signInWithGoogle(BuildContext context) async {
    try {
      await InternetAddress.lookup("google.com");
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      // Obtain the auth details from the request
      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      // Once signed in, return the UserCredential
      return await FirebaseAuth.instance.signInWithCredential(credential);
    } catch (e) {
      log("error in google sign in${e}");
      Commonwidgets.ShowSanckbar(context, "error in network${e}");
    }
    return null;
  }

  handleGoogleSignIn(BuildContext context) async {
    Commonwidgets.progressindicator(context);
    try {
      signInWithGoogle(context).then((value) async {
        Navigator.pop(context);
        if (value != null) {
          if (await (Apis.userexist())) {
            Get.to(() => homepage());
          }
          log("user details${value.user}additional ${value.additionalUserInfo}");
          Commonwidgets.GetSnackbar(
            "Sign in Success",
            "${value.user?.displayName}",
            null,
            null,
            NetworkImage(
              "${value.user?.photoURL}",
            ),
            context,
          );
        } else {
          await Apis.Createuser().then((value) {
            Get.to(() => homepage());
          });
        }
      });
    } catch (e) {
      // Handle sign-in errors
      print("Error signing in with Google: $e");
    }
  }
}
