import 'package:chatapplication/auth/apis.dart';
import 'package:chatapplication/color/Color.dart';
import 'package:chatapplication/commonwidgets/ChatCard/chatcard.dart';
import 'package:chatapplication/model/homepage/homepagemodel.dart';
import 'package:chatapplication/view/homepage/controller/homepagecontroller.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class homepage extends StatelessWidget {
  const homepage({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(HomepageController());
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: shadeColor,
        backgroundColor: primaryColor,
        centerTitle: true,
        title: Text("ChAt Us"),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.home,
              color: Colors.white,
            )),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.search)),
          IconButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                await GoogleSignIn().signOut();
              },
              icon: Icon(Icons.output_rounded)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.chat),
      ),
      body: StreamBuilder(
        stream: Apis.firestore.collection('user').snapshots(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
            case ConnectionState.none:
              return Center(child: CircularProgressIndicator());
            case ConnectionState.active:
            case ConnectionState.done:
              final data = snapshot.data?.docs;
              controller.List.value =
                  data?.map((e) => Chatusers.fromJson(e.data())).toList() ?? [];
              if (controller.List.value.isNotEmpty) {
                return ListView.builder(
                  padding: EdgeInsets.only(top: 15),
                  physics: BouncingScrollPhysics(),
                  itemCount: controller.List.length,
                  itemBuilder: (context, index) => chatcard(
                    username: "${controller.List[index].name}",
                    description: "${controller.List[index].about}",
                    time: "${controller.List[index].createdAt}",
                  ),
                );
              } else {
                return Center(child: Text("No data found"));
              }
          }
          // if (snapshot.hasData) {
          //
          //   for (var i in data!) {
          //     log("response = ${jsonEncode(i.data())}");
          //     controller.List.add(i.data()["name"]);
          //   }
          // }
        },
      ),
    );
  }
}
