import 'package:get/get.dart';

import '../../../model/homepage/homepagemodel.dart';

class HomepageController extends GetxController {
  var List = <Chatusers>[].obs;
}
