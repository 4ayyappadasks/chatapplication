import 'package:chatapplication/model/homepage/homepagemodel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Apis {
  static FirebaseAuth auth = FirebaseAuth.instance;
  static FirebaseFirestore firestore = FirebaseFirestore.instance;
  static User get user => auth.currentUser!;

  /// user exist
  static Future<bool> userexist() async {
    return (await firestore.collection("user").doc(auth.currentUser!.uid).get())
        .exists;
  }

  /// user create
  static Future<void> Createuser() async {
    final dateandtime = DateTime.now().millisecondsSinceEpoch.toString();
    final chatuser = Chatusers(
        id: auth.currentUser!.uid,
        name: auth.currentUser!.displayName.toString(),
        image: auth.currentUser!.photoURL.toString(),
        email: auth.currentUser!.email.toString(),
        createdAt: dateandtime,
        about: "using a chat",
        isOnline: false,
        lastActive: dateandtime,
        pushToken: "");
    return (await firestore
        .collection("user")
        .doc(auth.currentUser!.uid)
        .set(chatuser.toJson()));
  }
}
